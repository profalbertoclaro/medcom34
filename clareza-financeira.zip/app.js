const STORAGE_KEY = "clareza-financeira:v1";

const incomeCategories = ["Salário", "Freelance", "Investimentos", "Reembolso", "Outras receitas"];
const expenseCategories = [
  "Moradia",
  "Mercado",
  "Transporte",
  "Saúde",
  "Educação",
  "Lazer",
  "Assinaturas",
  "Outras despesas",
];

const currency = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});

const dateFormatter = new Intl.DateTimeFormat("pt-BR", {
  day: "2-digit",
  month: "short",
});

const fullMonthFormatter = new Intl.DateTimeFormat("pt-BR", {
  month: "long",
  year: "numeric",
});

const state = loadState();
let selectedMonth = getCurrentMonth();
let toastTimer = null;

const elements = {
  monthPicker: document.querySelector("#monthPicker"),
  periodLabel: document.querySelector("#periodLabel"),
  metricBalance: document.querySelector("#metricBalance"),
  metricBalanceHint: document.querySelector("#metricBalanceHint"),
  metricIncome: document.querySelector("#metricIncome"),
  metricExpense: document.querySelector("#metricExpense"),
  metricSavingsRate: document.querySelector("#metricSavingsRate"),
  incomeCount: document.querySelector("#incomeCount"),
  expenseCount: document.querySelector("#expenseCount"),
  budgetStatus: document.querySelector("#budgetStatus"),
  categoryInput: document.querySelector("#categoryInput"),
  dateInput: document.querySelector("#dateInput"),
  transactionForm: document.querySelector("#transactionForm"),
  transactionFormTitle: document.querySelector("#transactionFormTitle"),
  cancelEdit: document.querySelector("#cancelEdit"),
  transactionList: document.querySelector("#transactionList"),
  recentTransactions: document.querySelector("#recentTransactions"),
  transactionListSummary: document.querySelector("#transactionListSummary"),
  searchInput: document.querySelector("#searchInput"),
  typeFilter: document.querySelector("#typeFilter"),
  categoryBreakdown: document.querySelector("#categoryBreakdown"),
  healthList: document.querySelector("#healthList"),
  cashflowChart: document.querySelector("#cashflowChart"),
  budgetForm: document.querySelector("#budgetForm"),
  budgetCategory: document.querySelector("#budgetCategory"),
  budgetAmount: document.querySelector("#budgetAmount"),
  budgetList: document.querySelector("#budgetList"),
  budgetSummary: document.querySelector("#budgetSummary"),
  goalForm: document.querySelector("#goalForm"),
  goalList: document.querySelector("#goalList"),
  goalSummary: document.querySelector("#goalSummary"),
  exportCsv: document.querySelector("#exportCsv"),
  importCsv: document.querySelector("#importCsv"),
  toast: document.querySelector("#toast"),
};

boot();

function boot() {
  elements.monthPicker.value = selectedMonth;
  elements.dateInput.value = todayISO();

  populateCategorySelect(elements.categoryInput, incomeCategories);
  populateCategorySelect(elements.budgetCategory, expenseCategories);

  bindEvents();
  render();
  registerServiceWorker();
}

function bindEvents() {
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.addEventListener("click", () => activateTab(tab.dataset.tab));
  });

  document.querySelectorAll("[data-go-tab]").forEach((button) => {
    button.addEventListener("click", () => activateTab(button.dataset.goTab));
  });

  elements.monthPicker.addEventListener("change", () => {
    selectedMonth = elements.monthPicker.value || getCurrentMonth();
    render();
  });

  elements.transactionForm.addEventListener("change", (event) => {
    if (event.target.name === "type") {
      updateTransactionCategories();
    }
  });

  elements.transactionForm.addEventListener("submit", handleTransactionSubmit);
  elements.cancelEdit.addEventListener("click", resetTransactionForm);
  elements.searchInput.addEventListener("input", renderTransactions);
  elements.typeFilter.addEventListener("change", renderTransactions);
  elements.budgetForm.addEventListener("submit", handleBudgetSubmit);
  elements.goalForm.addEventListener("submit", handleGoalSubmit);
  elements.exportCsv.addEventListener("click", exportCsv);
  elements.importCsv.addEventListener("change", importCsv);
  window.addEventListener("resize", renderChart);
}

function loadState() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved) {
    try {
      const parsed = JSON.parse(saved);
      return {
        transactions: Array.isArray(parsed.transactions) ? parsed.transactions : [],
        budgets: parsed.budgets || {},
        goals: Array.isArray(parsed.goals) ? parsed.goals : [],
      };
    } catch {
      localStorage.removeItem(STORAGE_KEY);
    }
  }

  return createSeedState();
}

function createSeedState() {
  const month = getCurrentMonth();
  const dated = (day) => `${month}-${String(day).padStart(2, "0")}`;

  return {
    transactions: [
      transaction("income", "Salário", "Salário", 5200, dated(5)),
      transaction("income", "Projeto extra", "Freelance", 900, dated(12)),
      transaction("expense", "Aluguel", "Moradia", 1650, dated(6)),
      transaction("expense", "Supermercado", "Mercado", 740.35, dated(8)),
      transaction("expense", "Transporte por app", "Transporte", 218.9, dated(11)),
      transaction("expense", "Plano de saúde", "Saúde", 420, dated(14)),
      transaction("expense", "Cinema e jantar", "Lazer", 186.4, dated(17)),
      transaction("expense", "Cursos online", "Educação", 129.9, dated(18)),
    ],
    budgets: {
      Moradia: 1800,
      Mercado: 950,
      Transporte: 350,
      Saúde: 500,
      Educação: 250,
      Lazer: 320,
      Assinaturas: 120,
    },
    goals: [
      goal("Reserva de emergência", 12000, 4200, addMonthsISO(8)),
      goal("Viagem", 4500, 1250, addMonthsISO(5)),
    ],
  };
}

function persist() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function render() {
  elements.periodLabel.textContent = capitalize(monthLabel(selectedMonth));
  renderMetrics();
  renderTransactions();
  renderRecentTransactions();
  renderCategoryBreakdown();
  renderHealth();
  renderBudgets();
  renderGoals();
  renderChart();
}

function renderMetrics() {
  const transactions = transactionsForMonth();
  const income = sumByType(transactions, "income");
  const expense = sumByType(transactions, "expense");
  const balance = income - expense;
  const savingsRate = income > 0 ? Math.round((balance / income) * 100) : 0;
  const incomeCount = transactions.filter((item) => item.type === "income").length;
  const expenseCount = transactions.filter((item) => item.type === "expense").length;
  const budgetRatio = getBudgetRatio();

  elements.metricBalance.textContent = currency.format(balance);
  elements.metricIncome.textContent = currency.format(income);
  elements.metricExpense.textContent = currency.format(expense);
  elements.metricSavingsRate.textContent = `${Math.max(savingsRate, 0)}%`;
  elements.metricBalanceHint.textContent = balance >= 0 ? "Resultado positivo" : "Atenção ao fechamento";
  elements.incomeCount.textContent = pluralize(incomeCount, "lançamento");
  elements.expenseCount.textContent = pluralize(expenseCount, "lançamento");

  if (budgetRatio > 1) {
    elements.budgetStatus.textContent = "Limites ultrapassados";
  } else if (budgetRatio > 0.8) {
    elements.budgetStatus.textContent = "Perto do limite";
  } else {
    elements.budgetStatus.textContent = "Orçamento sob controle";
  }
}

function renderTransactions() {
  const filtered = filteredTransactions();
  elements.transactionListSummary.textContent = pluralize(filtered.length, "lançamento");
  elements.transactionList.replaceChildren();

  if (!filtered.length) {
    elements.transactionList.append(emptyState("Nenhuma transação encontrada."));
    return;
  }

  filtered.forEach((item) => {
    elements.transactionList.append(transactionRow(item, true));
  });
}

function renderRecentTransactions() {
  const recent = transactionsForMonth()
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 5);

  elements.recentTransactions.replaceChildren();

  if (!recent.length) {
    elements.recentTransactions.append(emptyState("Sem lançamentos neste mês."));
    return;
  }

  recent.forEach((item) => {
    elements.recentTransactions.append(transactionRow(item, false));
  });
}

function transactionRow(item, withActions) {
  const row = document.createElement("div");
  row.className = "transaction-row";

  const meta = document.createElement("div");
  meta.className = "transaction-meta";

  const title = document.createElement("span");
  title.className = "transaction-title";
  title.textContent = item.description;

  const date = document.createElement("span");
  date.className = "muted";
  date.textContent = formatDate(item.date);

  meta.append(title, date);

  const category = document.createElement("span");
  category.className = "chip";
  category.textContent = item.category;

  const amount = document.createElement("span");
  amount.className = `amount ${item.type}`;
  amount.textContent = `${item.type === "income" ? "+" : "-"} ${currency.format(item.amount)}`;

  row.append(meta, category, amount);

  if (withActions) {
    const actions = document.createElement("div");
    actions.className = "transaction-actions";

    const edit = iconButton("Editar", "edit");
    edit.addEventListener("click", () => startEditTransaction(item.id));

    const remove = iconButton("Excluir", "trash");
    remove.addEventListener("click", () => deleteTransaction(item.id));

    actions.append(edit, remove);
    row.append(actions);
  }

  return row;
}

function renderCategoryBreakdown() {
  const expenses = transactionsForMonth().filter((item) => item.type === "expense");
  const total = sum(expenses.map((item) => item.amount));
  const byCategory = groupSum(expenses, "category");
  const rows = Object.entries(byCategory)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6);

  elements.categoryBreakdown.replaceChildren();

  if (!rows.length) {
    elements.categoryBreakdown.append(emptyState("Sem despesas neste mês."));
    return;
  }

  rows.forEach(([category, amount]) => {
    const percent = total > 0 ? (amount / total) * 100 : 0;
    const row = document.createElement("div");
    row.className = "breakdown-row";
    row.append(
      pairLine(category, currency.format(amount), "breakdown-top"),
      progress(percent, categoryColor(category)),
    );
    elements.categoryBreakdown.append(row);
  });
}

function renderHealth() {
  const transactions = transactionsForMonth();
  const income = sumByType(transactions, "income");
  const expense = sumByType(transactions, "expense");
  const balance = income - expense;
  const budgetRatio = getBudgetRatio();
  const biggestExpense = Object.entries(groupSum(transactions.filter((item) => item.type === "expense"), "category"))
    .sort((a, b) => b[1] - a[1])[0];

  const items = [
    {
      label: balance >= 0 ? "Mês positivo" : "Mês negativo",
      value: currency.format(balance),
      status: balance >= 0 ? "ok" : "danger",
    },
    {
      label: "Uso dos orçamentos",
      value: `${Math.round(budgetRatio * 100)}%`,
      status: budgetRatio > 1 ? "danger" : budgetRatio > 0.8 ? "warning" : "ok",
    },
    {
      label: biggestExpense ? `Maior gasto: ${biggestExpense[0]}` : "Maior gasto",
      value: biggestExpense ? currency.format(biggestExpense[1]) : currency.format(0),
      status: "ok",
    },
  ];

  elements.healthList.replaceChildren();

  items.forEach((item) => {
    const row = document.createElement("div");
    row.className = "health-item";

    const left = document.createElement("div");
    left.className = "health-label";

    const dot = document.createElement("span");
    dot.className = `status-dot ${item.status === "ok" ? "" : item.status}`;

    const label = document.createElement("strong");
    label.textContent = item.label;

    left.append(dot, label);

    const value = document.createElement("span");
    value.className = "muted";
    value.textContent = item.value;

    row.append(left, value);
    elements.healthList.append(row);
  });
}

function renderBudgets() {
  const spentByCategory = groupSum(transactionsForMonth().filter((item) => item.type === "expense"), "category");
  const entries = Object.entries(state.budgets).sort((a, b) => a[0].localeCompare(b[0], "pt-BR"));

  elements.budgetList.replaceChildren();
  elements.budgetSummary.textContent = pluralize(entries.length, "categoria com limite");

  if (!entries.length) {
    elements.budgetList.append(emptyState("Nenhum orçamento cadastrado."));
    return;
  }

  entries.forEach(([category, limit]) => {
    const spent = spentByCategory[category] || 0;
    const percent = limit > 0 ? (spent / limit) * 100 : 0;
    const color = percent > 100 ? "var(--expense)" : percent > 80 ? "var(--amber)" : categoryColor(category);

    const item = document.createElement("div");
    item.className = "budget-item";

    const top = pairLine(category, `${currency.format(spent)} / ${currency.format(limit)}`, "budget-top");
    const help = document.createElement("div");
    help.className = "muted";
    help.textContent = percent > 100 ? "Limite ultrapassado" : `${Math.round(percent)}% usado`;

    item.append(top, progress(percent, color), help);
    elements.budgetList.append(item);
  });
}

function renderGoals() {
  elements.goalList.replaceChildren();
  elements.goalSummary.textContent = pluralize(state.goals.length, "meta cadastrada");

  if (!state.goals.length) {
    elements.goalList.append(emptyState("Nenhuma meta cadastrada."));
    return;
  }

  state.goals.forEach((item) => {
    const percent = item.target > 0 ? (item.saved / item.target) * 100 : 0;
    const goalItem = document.createElement("div");
    goalItem.className = "goal-item";

    const top = pairLine(item.name, `${Math.round(percent)}%`, "goal-top");
    const detail = document.createElement("p");
    detail.className = "muted";
    detail.textContent = `${currency.format(item.saved)} de ${currency.format(item.target)}${item.deadline ? ` até ${formatDate(item.deadline)}` : ""}`;

    const actions = document.createElement("div");
    actions.className = "goal-actions";

    const input = document.createElement("input");
    input.type = "number";
    input.min = "0";
    input.step = "0.01";
    input.inputMode = "decimal";
    input.value = item.saved;
    input.setAttribute("aria-label", `Valor guardado para ${item.name}`);

    const update = document.createElement("button");
    update.className = "button button-secondary";
    update.type = "button";
    update.textContent = "Atualizar";
    update.addEventListener("click", () => updateGoal(item.id, input.value));

    const remove = iconButton("Excluir meta", "trash");
    remove.addEventListener("click", () => deleteGoal(item.id));

    actions.append(input, update, remove);
    goalItem.append(top, detail, progress(percent, "var(--blue)"), actions);
    elements.goalList.append(goalItem);
  });
}

function renderChart() {
  const canvas = elements.cashflowChart;
  const context = canvas.getContext("2d");
  const rect = canvas.getBoundingClientRect();
  const width = Math.max(rect.width, 320);
  const height = Math.max(rect.height, 220);
  const ratio = window.devicePixelRatio || 1;

  canvas.width = Math.floor(width * ratio);
  canvas.height = Math.floor(height * ratio);
  context.setTransform(ratio, 0, 0, ratio, 0, 0);
  context.clearRect(0, 0, width, height);

  const days = daysInMonth(selectedMonth);
  const daily = Array.from({ length: days }, (_, index) => ({
    day: index + 1,
    income: 0,
    expense: 0,
    balance: 0,
  }));

  transactionsForMonth().forEach((item) => {
    const day = Number(item.date.slice(-2)) - 1;
    if (!daily[day]) return;
    daily[day][item.type] += item.amount;
  });

  let running = 0;
  daily.forEach((item) => {
    running += item.income - item.expense;
    item.balance = running;
  });

  const maxValue = Math.max(
    1,
    ...daily.map((item) => item.income),
    ...daily.map((item) => item.expense),
    ...daily.map((item) => Math.abs(item.balance)),
  );

  const pad = { top: 22, right: 20, bottom: 36, left: 58 };
  const chartWidth = width - pad.left - pad.right;
  const chartHeight = height - pad.top - pad.bottom;
  const zeroY = pad.top + chartHeight * 0.58;
  const barWidth = Math.max(4, chartWidth / days - 3);

  drawGrid(context, pad, width, height, zeroY);

  daily.forEach((item, index) => {
    const x = pad.left + (index / days) * chartWidth + 1;
    const incomeHeight = (item.income / maxValue) * (chartHeight * 0.42);
    const expenseHeight = (item.expense / maxValue) * (chartHeight * 0.42);

    context.fillStyle = "rgba(31, 138, 91, 0.82)";
    context.fillRect(x, zeroY - incomeHeight, barWidth, incomeHeight);

    context.fillStyle = "rgba(200, 66, 58, 0.78)";
    context.fillRect(x, zeroY + 1, barWidth, expenseHeight);
  });

  context.beginPath();
  daily.forEach((item, index) => {
    const x = pad.left + (index / Math.max(days - 1, 1)) * chartWidth;
    const y = zeroY - (item.balance / maxValue) * (chartHeight * 0.42);
    if (index === 0) {
      context.moveTo(x, y);
    } else {
      context.lineTo(x, y);
    }
  });
  context.strokeStyle = "#2f6fab";
  context.lineWidth = 2.5;
  context.stroke();

  context.fillStyle = "#67716f";
  context.font = "12px system-ui, sans-serif";
  context.fillText("Receitas", pad.left, 18);
  context.fillText("Despesas", pad.left + 86, 18);
  context.fillText("Saldo", pad.left + 174, 18);

  drawLegendDot(context, pad.left - 12, 14, "#1f8a5b");
  drawLegendDot(context, pad.left + 74, 14, "#c8423a");
  drawLegendDot(context, pad.left + 162, 14, "#2f6fab");
}

function drawGrid(context, pad, width, height, zeroY) {
  context.strokeStyle = "#dce4e1";
  context.lineWidth = 1;
  context.beginPath();
  context.moveTo(pad.left, zeroY);
  context.lineTo(width - pad.right, zeroY);
  context.stroke();

  context.strokeStyle = "rgba(220, 228, 225, 0.72)";
  for (let index = 0; index < 4; index += 1) {
    const y = pad.top + (index / 3) * (height - pad.top - pad.bottom);
    context.beginPath();
    context.moveTo(pad.left, y);
    context.lineTo(width - pad.right, y);
    context.stroke();
  }

  context.fillStyle = "#67716f";
  context.font = "12px system-ui, sans-serif";
  context.fillText("1", pad.left, height - 12);
  context.fillText(String(daysInMonth(selectedMonth)), width - pad.right - 18, height - 12);
}

function drawLegendDot(context, x, y, color) {
  context.beginPath();
  context.arc(x, y - 4, 4, 0, Math.PI * 2);
  context.fillStyle = color;
  context.fill();
}

function handleTransactionSubmit(event) {
  event.preventDefault();
  const form = new FormData(elements.transactionForm);
  const amount = Number(form.get("amount"));

  if (!Number.isFinite(amount) || amount <= 0) {
    showToast("Informe um valor maior que zero.");
    return;
  }

  const payload = {
    type: form.get("type"),
    description: String(form.get("description")).trim(),
    category: form.get("category"),
    amount,
    date: form.get("date"),
  };

  if (elements.transactionForm.dataset.editingId) {
    const id = elements.transactionForm.dataset.editingId;
    const index = state.transactions.findIndex((item) => item.id === id);
    if (index >= 0) {
      state.transactions[index] = { ...state.transactions[index], ...payload };
      showToast("Transação atualizada.");
    }
  } else {
    state.transactions.push({ id: crypto.randomUUID(), ...payload });
    showToast("Transação salva.");
  }

  selectedMonth = payload.date.slice(0, 7);
  elements.monthPicker.value = selectedMonth;
  resetTransactionForm();
  persist();
  render();
}

function startEditTransaction(id) {
  const item = state.transactions.find((entry) => entry.id === id);
  if (!item) return;

  elements.transactionForm.dataset.editingId = id;
  elements.transactionFormTitle.textContent = "Editar transação";
  elements.cancelEdit.hidden = false;
  elements.transactionForm.elements.type.value = item.type;
  updateTransactionCategories(item.category);
  elements.transactionForm.elements.description.value = item.description;
  elements.transactionForm.elements.amount.value = item.amount;
  elements.transactionForm.elements.date.value = item.date;
  elements.transactionForm.elements.category.value = item.category;
  activateTab("transactions");
}

function deleteTransaction(id) {
  const item = state.transactions.find((entry) => entry.id === id);
  if (!item) return;

  const confirmed = window.confirm(`Excluir "${item.description}"?`);
  if (!confirmed) return;

  state.transactions = state.transactions.filter((entry) => entry.id !== id);
  persist();
  render();
  showToast("Transação excluída.");
}

function resetTransactionForm() {
  delete elements.transactionForm.dataset.editingId;
  elements.transactionForm.reset();
  elements.transactionForm.elements.type.value = "income";
  elements.dateInput.value = todayISO();
  elements.transactionFormTitle.textContent = "Nova transação";
  elements.cancelEdit.hidden = true;
  updateTransactionCategories();
}

function updateTransactionCategories(selected) {
  const type = elements.transactionForm.elements.type.value;
  populateCategorySelect(elements.categoryInput, type === "income" ? incomeCategories : expenseCategories, selected);
}

function handleBudgetSubmit(event) {
  event.preventDefault();
  const category = elements.budgetCategory.value;
  const amount = Number(elements.budgetAmount.value);

  if (!Number.isFinite(amount) || amount <= 0) {
    showToast("Informe um limite maior que zero.");
    return;
  }

  state.budgets[category] = amount;
  elements.budgetForm.reset();
  persist();
  render();
  showToast("Orçamento atualizado.");
}

function handleGoalSubmit(event) {
  event.preventDefault();
  const name = document.querySelector("#goalName").value.trim();
  const target = Number(document.querySelector("#goalTarget").value);
  const saved = Number(document.querySelector("#goalSaved").value);
  const deadline = document.querySelector("#goalDeadline").value;

  if (!name || !Number.isFinite(target) || target <= 0 || !Number.isFinite(saved)) {
    showToast("Preencha os dados da meta.");
    return;
  }

  state.goals.push(goal(name, target, Math.max(saved, 0), deadline));
  elements.goalForm.reset();
  document.querySelector("#goalSaved").value = 0;
  persist();
  render();
  showToast("Meta criada.");
}

function updateGoal(id, value) {
  const item = state.goals.find((entry) => entry.id === id);
  const amount = Number(value);
  if (!item || !Number.isFinite(amount) || amount < 0) {
    showToast("Informe um valor válido.");
    return;
  }

  item.saved = amount;
  persist();
  render();
  showToast("Meta atualizada.");
}

function deleteGoal(id) {
  const item = state.goals.find((entry) => entry.id === id);
  if (!item) return;

  const confirmed = window.confirm(`Excluir a meta "${item.name}"?`);
  if (!confirmed) return;

  state.goals = state.goals.filter((entry) => entry.id !== id);
  persist();
  render();
  showToast("Meta excluída.");
}

function exportCsv() {
  const headers = ["tipo", "data", "categoria", "descricao", "valor"];
  const rows = state.transactions.map((item) => [
    item.type === "income" ? "receita" : "despesa",
    item.date,
    item.category,
    item.description,
    String(item.amount).replace(".", ","),
  ]);
  const csv = [headers, ...rows].map((row) => row.map(csvCell).join(";")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `clareza-financeira-${selectedMonth}.csv`;
  anchor.click();
  URL.revokeObjectURL(url);
}

function importCsv(event) {
  const file = event.target.files?.[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    const rows = parseCsv(String(reader.result || ""));
    const imported = rows.slice(1).map(rowToTransaction).filter(Boolean);
    state.transactions.push(...imported);
    persist();
    render();
    showToast(`${imported.length} transações importadas.`);
    elements.importCsv.value = "";
  };
  reader.readAsText(file);
}

function rowToTransaction(row) {
  const [tipo, data, categoria, descricao, valor] = row;
  if (!data || !categoria || !descricao || !valor) return null;

  const type = normalizeText(tipo).includes("receita") || normalizeText(tipo).includes("income")
    ? "income"
    : "expense";
  const amount = Number(String(valor).replace(/\./g, "").replace(",", "."));
  if (!Number.isFinite(amount) || amount <= 0) return null;

  return {
    id: crypto.randomUUID(),
    type,
    date: data,
    category: categoria,
    description: descricao,
    amount,
  };
}

function parseCsv(text) {
  return text
    .split(/\r?\n/)
    .filter(Boolean)
    .map((line) => {
      const separator = line.includes(";") ? ";" : ",";
      const cells = [];
      let value = "";
      let quoted = false;

      for (const char of line) {
        if (char === '"') {
          quoted = !quoted;
        } else if (char === separator && !quoted) {
          cells.push(value.trim());
          value = "";
        } else {
          value += char;
        }
      }

      cells.push(value.trim());
      return cells.map((cell) => cell.replace(/^"|"$/g, "").replace(/""/g, '"'));
    });
}

function filteredTransactions() {
  const search = normalizeText(elements.searchInput.value);
  const type = elements.typeFilter.value;

  return transactionsForMonth()
    .filter((item) => type === "all" || item.type === type)
    .filter((item) => {
      if (!search) return true;
      return normalizeText(`${item.description} ${item.category}`).includes(search);
    })
    .sort((a, b) => b.date.localeCompare(a.date));
}

function transactionsForMonth() {
  return state.transactions.filter((item) => item.date?.startsWith(selectedMonth));
}

function sumByType(transactions, type) {
  return sum(transactions.filter((item) => item.type === type).map((item) => item.amount));
}

function getBudgetRatio() {
  const limits = Object.values(state.budgets);
  const totalLimit = sum(limits);
  if (!totalLimit) return 0;
  const spent = sumByType(transactionsForMonth(), "expense");
  return spent / totalLimit;
}

function transaction(type, description, category, amount, date) {
  return {
    id: crypto.randomUUID(),
    type,
    description,
    category,
    amount,
    date,
  };
}

function goal(name, target, saved, deadline) {
  return {
    id: crypto.randomUUID(),
    name,
    target,
    saved,
    deadline,
  };
}

function activateTab(name) {
  document.querySelectorAll(".tab").forEach((tab) => {
    tab.classList.toggle("is-active", tab.dataset.tab === name);
  });

  document.querySelectorAll(".tab-panel").forEach((panel) => {
    panel.classList.toggle("is-active", panel.dataset.panel === name);
  });

  if (name === "overview") {
    requestAnimationFrame(renderChart);
  }
}

function populateCategorySelect(select, categories, selected) {
  select.replaceChildren();
  categories.forEach((category) => {
    const option = document.createElement("option");
    option.value = category;
    option.textContent = category;
    select.append(option);
  });

  if (selected && categories.includes(selected)) {
    select.value = selected;
  }
}

function emptyState(message) {
  const box = document.createElement("div");
  box.className = "empty-state";
  box.textContent = message;
  return box;
}

function pairLine(leftText, rightText, className) {
  const top = document.createElement("div");
  top.className = className;

  const left = document.createElement("span");
  left.className = className.includes("goal") ? "goal-name" : className.includes("budget") ? "budget-name" : "breakdown-name";
  left.textContent = leftText;

  const right = document.createElement("strong");
  right.textContent = rightText;

  top.append(left, right);
  return top;
}

function progress(value, color) {
  const progressBar = document.createElement("div");
  progressBar.className = "progress";
  progressBar.style.setProperty("--value", `${Math.max(0, Math.min(value, 100))}%`);
  progressBar.style.setProperty("--bar-color", color);
  progressBar.append(document.createElement("span"));
  return progressBar;
}

function iconButton(label, icon) {
  const button = document.createElement("button");
  button.className = "icon-button";
  button.type = "button";
  button.title = label;
  button.setAttribute("aria-label", label);
  button.innerHTML = iconSvg(icon);
  return button;
}

function iconSvg(name) {
  const icons = {
    edit: '<svg viewBox="0 0 24 24"><path d="M12 20h9"/><path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>',
    trash: '<svg viewBox="0 0 24 24"><path d="M3 6h18"/><path d="M8 6V4h8v2"/><path d="M19 6l-1 14H6L5 6"/><path d="M10 11v5"/><path d="M14 11v5"/></svg>',
  };
  return icons[name] || "";
}

function categoryColor(category) {
  const colors = {
    Moradia: "var(--primary)",
    Mercado: "var(--blue)",
    Transporte: "var(--amber)",
    Saúde: "#6f5aa8",
    Educação: "#237b80",
    Lazer: "#bf5b30",
    Assinaturas: "#7c6f55",
  };
  return colors[category] || "var(--primary)";
}

function groupSum(items, key) {
  return items.reduce((acc, item) => {
    acc[item[key]] = (acc[item[key]] || 0) + item.amount;
    return acc;
  }, {});
}

function sum(values) {
  return values.reduce((total, value) => total + Number(value || 0), 0);
}

function formatDate(value) {
  return dateFormatter.format(new Date(`${value}T12:00:00`));
}

function monthLabel(value) {
  return fullMonthFormatter.format(new Date(`${value}-02T12:00:00`));
}

function getCurrentMonth() {
  return localDateISO().slice(0, 7);
}

function todayISO() {
  return localDateISO();
}

function daysInMonth(month) {
  const [year, monthIndex] = month.split("-").map(Number);
  return new Date(year, monthIndex, 0).getDate();
}

function addMonthsISO(quantity) {
  const date = new Date();
  date.setMonth(date.getMonth() + quantity);
  return localDateISO(date);
}

function localDateISO(date = new Date()) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function pluralize(count, singular) {
  return `${count} ${singular}${count === 1 ? "" : "s"}`;
}

function capitalize(value) {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function normalizeText(value) {
  return String(value || "")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function csvCell(value) {
  const text = String(value ?? "");
  if (/[;"\n]/.test(text)) {
    return `"${text.replace(/"/g, '""')}"`;
  }
  return text;
}

function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.classList.add("is-visible");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => {
    elements.toast.classList.remove("is-visible");
  }, 2600);
}

function registerServiceWorker() {
  const canUseServiceWorker =
    "serviceWorker" in navigator &&
    ["http:", "https:"].includes(window.location.protocol);

  if (!canUseServiceWorker) return;

  window.addEventListener("load", () => {
    navigator.serviceWorker.register("./service-worker.js").catch(() => {
      // O app continua funcionando; o cache offline só depende deste registro.
    });
  });
}
