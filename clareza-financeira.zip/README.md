# Clareza Financeira

Aplicativo local de gerenciamento financeiro pessoal feito com HTML, CSS e JavaScript puro.

## Como abrir

Abra `index.html` no navegador.

## Como usar no iPhone

Para funcionar bem no iOS, publique a pasta em um endereço `https://` ou rode em um servidor local acessível pelo iPhone. No Safari, abra o endereço do app e use **Compartilhar > Adicionar à Tela de Início**.

Depois de aberto por `https://`, o app registra um service worker e mantém a interface disponível offline. Os seus dados ficam salvos no navegador do próprio aparelho via `localStorage`.

## O que já funciona

- Dashboard mensal com receitas, despesas, saldo e taxa de poupança.
- Cadastro, edição, exclusão e filtro de transações.
- Orçamentos por categoria com acompanhamento de limite.
- Metas financeiras com progresso editável.
- Gráfico mensal em canvas.
- Dados salvos no navegador com `localStorage`.
- Exportação e importação de transações em CSV.
